export const environment = {
    production: true,
    serverUrl: 'http://ec2-35-182-240-14.ca-central-1.compute.amazonaws.com:3000',
};
