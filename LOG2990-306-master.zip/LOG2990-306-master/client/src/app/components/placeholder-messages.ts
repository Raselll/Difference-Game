export interface Message {
    user: string;
    time: string;
    content: string;
}
