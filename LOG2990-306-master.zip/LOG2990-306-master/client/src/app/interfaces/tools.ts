export enum Tools {
    Pencil = 'pencil',
    Eraser = 'eraser',
    Rectangle = 'rectangle',
    None = 'none',
}
