export interface Vec2 {
    x: number;
    y: number;
}
