import { TimeFormatting } from './time-formatting';

describe('TimeFormatting', () => {
    it('should create an instance', () => {
        expect(new TimeFormatting()).toBeTruthy();
    });
});
