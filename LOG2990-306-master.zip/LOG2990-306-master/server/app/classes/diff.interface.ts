export interface FindDifferences {
    img0: string;
    img1: string;
    radius: number;
}
